library to switch between normal, superscripts, subscripts and caps.
Includes latin and greek letters, numbers and basic operands.